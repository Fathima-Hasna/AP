
package beverage_client;

/* The necessary import statements (which contain external packages or certain classes) are imported into the program */

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.net.Socket;
import java.util.Scanner;

/* The class Beverage_Client implements the Runnable interface which allows its instances to be executed by as a thread */

public class Beverage_Client implements Runnable {
    @Override
    
/* The run() method helps run the thread after the thread starts from the main class */    
    
 public void run()
  {   
      
    try
        {
            
/* Socket establishes a connection with the server by calling a local host and defining a particular
            port number which is also used on server side */            
            Socket vm = new Socket("localhost",2587);
 
/* Scanner class is used to receive the needed information from the user */               
            Scanner inputdata = new Scanner(System.in);
 
/* These print statements are displayed to the user so that they can enter
            the appropriate data which are also validated by methods of Scanner class */               
            System.out.println("Enter the Beverage Code");
            int bev_id = inputdata.nextInt();
            System.out.println("Enter the Number of Cups Dispensed");
            int num_cups = inputdata.nextInt();
            
 /* The data entered by the user is sent to server side using DataOutputStream class */              
            DataOutputStream data_ot_str = new DataOutputStream(vm.getOutputStream());
            
/* The below methods based on different datatypes are applied on the object created by 
                    DataOutputStream class are then sent to the server side */                                
            data_ot_str.writeInt(bev_id);
            data_ot_str.writeInt(num_cups);
           
/* This method is used to make sure that data is immediately sent to the server side  */               
            data_ot_str.flush();
            
  /* The server uses DataInputStream class to receive data sent from the server side */                     
            DataInputStream data_in_str=new DataInputStream(vm.getInputStream());
            
/* The below methods are used to read the necessary data sent from server side */
            String bev_name = data_in_str.readUTF();
            double salesrtn = data_in_str.readDouble();

 /* This if statement is executed when a record is not found due to a missing Beverage_Code */   
            if (bev_name.equals("RECORD_NOT_FOUND")) {
                
/* This displays the statement that the record was not found  */                
                System.out.println("Record not found for Beverage Code: " + bev_id);
            } 
            else {
                
/* The following set of statements are displayed which show the results to the user  */                   
                System.out.println("The Beverage Code is: " + bev_id);
                System.out.println("The Beverage Name is: " + bev_name);
                System.out.println("The Sales Return of the Beverage is: " + salesrtn+" baizas");
                
 /* This is done to close the connection */                  
                data_ot_str.close();
                data_in_str.close();
                
/* This is done to close the server connection */                  
                vm.close();
 
/* To display that the server connection has been closed */                
                System.out.println("******Connection closed******");
                
            }
            

        }
    
/* The catch statement is used to catch any expected errors that might error and show an error message */       
            catch(Exception e)
        {
            System.out.println(e);
        }

 }
}
