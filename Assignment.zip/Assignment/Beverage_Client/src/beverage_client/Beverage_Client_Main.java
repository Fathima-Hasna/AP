
package beverage_client;

/* Threads allow a program to perform multiple tasks at once and are lightweight in nature*/

public class Beverage_Client_Main {
    
/* This contains the main class which is invoked to compile and run the file for the client side */    

    public static void main(String[] args) {
        
/* The instance of the class Beverage_Client (used for implementing Runnable interface)
        is used to connect the Thread objects */

/* The object beverage_menu is created for connecting the class Beverage_Client */
        Beverage_Client beverage_menu=new Beverage_Client();
        
/* A Thread object vending_machine is created by calling the above object for reference */        
        Thread vending_machine=new Thread(beverage_menu);
        
/* The Thread object uses the .start() method to start the thread's functions */         
        vending_machine.start();
    }
    
}
