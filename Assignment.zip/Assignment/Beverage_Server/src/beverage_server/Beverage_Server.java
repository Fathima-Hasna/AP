package beverage_server;

/* The necessary import statements (which contain external packages or certain classes) are imported into the program */

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/* The class Beverage_Server implements the Runnable interface which allows its instances to be executed by as a thread */

public class Beverage_Server implements Runnable{
    @Override

/* The run() method helps run the thread after the thread starts from the main class */    
    
    public void run()
    {
        
      try
        {
/* JDBC host address builds the connection between Java applications and database. 
            Here, Derby is an embedded Java database (Apache Database) within NetBeans used for creating a database named Beverage_Vending_Machine; 
            uses the username and password from the created database */
            
            String hostname = "jdbc:derby://localhost:1527/Beverage_Vending_Machine";
            String usrn = "Beverages";
            String passw = "drinks";
            
/* Used for establishing the connection to the database and register the drivers */
            Connection connec = DriverManager.getConnection(hostname,usrn,passw);
            
/* Server socket is waiting for client connections by using the same port number used in client side */
            ServerSocket vms = new ServerSocket(2587);
            System.out.println("Connection is currently running while accessing the client and database");

/* The while loop continuously runs the server to deal with incoming client requests */
            while (true) {
                Socket vm = vms.accept();
                                
/* The server uses DataInputStream class to receive data sent from the client side */
                DataInputStream data_in_str = new DataInputStream(vm.getInputStream());

/* The below methods are used to read the necessary data sent from client side */
                int bev_id = data_in_str.readInt();
                int num_cups = data_in_str.readInt();

 /* These are the details that will be displayed on the server output screen 
                by taking values from the client side*/               
                System.out.println("The Beverage Code is: " + bev_id);
                System.out.println("The Number of Cups Dispensed: " + num_cups);
                
/* This is used to create statements and the statement object is used for implementing simple SQL queries */
                Statement statmt = connec.createStatement();
                
/* The SQL query is stored in the object getbevdata which will give us the table data 
                through referencing Beverage_Code, which is unique for every row of data */                
                String getbevdata = "SELECT * FROM BEVERAGES.BEVERAGE_MENU WHERE BEVERAGE_CODE=" + bev_id;
                
/* statmt.execute() is used to execute the above SQL query */  
                statmt.execute(getbevdata);
                
 /* ResultSet is used to retrieve data from the executed query */               
                ResultSet bevresl = statmt.getResultSet();

/* The retrieved data is sent back to the client side using DataOutputStream class  */                
                DataOutputStream data_ot_str = new DataOutputStream(vm.getOutputStream());

/* The next() method is applied for the ResultSet object to move to the next row if the condition returns true, 
                otherwise it executes the statements in the else loop */                
                if (bevresl.next()) {
                    
/* The following lines of code retrieve the Beverage_Name and Price from the database */                   
                    String bev_name = bevresl.getString("Beverage_Name");
                    double bev_price = bevresl.getDouble("Price");
                    
/* The calculation for Sales Return is stored in the variable salesrtn 
                    which contains the following calculation */                    
                    double salesrtn = num_cups * bev_price;
                    
/* The below methods based on different datatypes are applied on the object created by 
                    DataOutputStream class are then sent to the client */                    
                    data_ot_str.writeUTF(bev_name);
                    data_ot_str.writeDouble(salesrtn);
                    
                } 
     
/* These statements are executed if no data is found for a particular Beverage_Code */                                    
                else {
 
/* When the Beverage_Name isn't available for a missing Beverage_code, it is equated with the string "RECORD_NOT_FOUND" */                    
                    data_ot_str.writeUTF("RECORD_NOT_FOUND");
                    
 /* When the Sales_Return cannot be computated because of the missing Beverage_Code, the value is equated to 0.0 */                 
                    data_ot_str.writeDouble(0.0);
                    
/* This is used to display that the record cannot be found along with their Beverage_Code */                    
                    System.out.println("Record Not Found for Beverage Code: " + bev_id);
                }

 /* These actions are performed to ensure that the data is immediately sent to client side */
                data_ot_str.flush();
                
/* This is done to close the connection */               
                data_ot_str.close();
                data_in_str.close();
                
 /* This is done to close the server connection */               
                vm.close();
               
 /* To display that the server connection has been closed */
 
                System.out.println("******Connection closed******");
            }
        }
 /* These two catch conditions are used to catch either general exceptions or exceptions from SQL queries and show error messages */     
      catch (IOException | SQLException e) {
            System.out.println(e);
            Logger.getLogger(Beverage_Server.class.getName()).log(Level.SEVERE, null, e);
        }

    }
         
}
