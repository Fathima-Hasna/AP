
package test1;

//Java code to demonstrate the working of TreeSet
import java.util.*;
        
public class Test1 {

    public static void main(String[] args) {
        
        //Creating TreeMap
        TreeMap<Integer,String> obj = new TreeMap<Integer,String>();
        
        //Adding object in TreeMap;
        obj.put(100,"Maths");
        obj.put(200,"English");
        obj.put(300,"Science");
        
        for (Map.Entry m:obj.entrySet())
        {
        System.out.println(m.getKey()+" "+m.getValue());
        }
    }
    
}
